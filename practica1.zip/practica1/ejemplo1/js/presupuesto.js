//prompt() permite obtener entrada de datos del usuario
var presupuesto = prompt('Ingrese el presupuesto anual','');
var derma,trau,pedi;
derma = presupuesto*0.40;
trau = presupuesto*0.35;
pedi = presupuesto*0.25;
//Durante el ciclo evitaremos utilizar manejadores de eventos
//dentro del marcado HTML. En este caso lo haremos porque 
//no hemos visto funciones. Nos referimos al manejador de eventos 
//onmouseover para cambiar dinámicamente el nombre de la clase
document.write("<h1 class='moneyOff' onMouseOver='this.className=\"moneyOn\"' onMouseOut='this.className=\"moneyOff\"'>El presupuesto asignado para Ginecología es: $" + derma + "</h1><hr>");
document.write("<h1 class='moneyOff' onMouseOver='this.className=\"moneyOn\"' onMouseOut='this.className=\"moneyOff\"'>El presupuesto asignado para Traumatología es: $" + trau + "</h1><hr>");
document.write("<h1 class='moneyOff' onMouseOver='this.className=\"moneyOn\"' onMouseOut='this.className=\"moneyOff\"'>El presupuesto asignado para Pediatría es: $" + pedi + "</h1><hr>");