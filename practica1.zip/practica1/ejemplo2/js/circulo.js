/* * * * * * * * * * * * * * * * * * * * * * * * * * * *
 * Materia: Lenguajes Interpretados en el Cliente      *
 * Archivo: circulo.js                                *
 * Uso: Calcular el área de un círculo.                *
 * Ciclo 02-2015                                       *
 * * * * * * * * * * * * * * * * * * * * * * * * * * * */
var PI = 3.1415926535;
var radio = prompt('Introduzca el radio del círculo:','');
var area;
area = PI*radio*radio;
document.write("<header><h1>El área del círculo es: " + area + "</h1><hr /><br /></header>");