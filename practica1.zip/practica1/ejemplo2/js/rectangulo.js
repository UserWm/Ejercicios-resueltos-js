/* * * * * * * * * * * * * * * * * * * * * * * * * * *
 * Materia: Lenguajes Interpretados en el Cliente    *
 * Archivo: rectangulo.js                            *
 * Uso: Calcular el área de un rectángulo.           *
 * Ciclo 02-2015                                     *
 * * * * * * * * * * * * * * * * * * * * * * * * * * */
var base = prompt('Introduzca la base del rectángulo','');
var altura = prompt('Introduzca la altura del rectángulo','');
var area;
area = base*altura
document.write("<header><h1>El área del rectángulo es: " + area + "</h1><hr /><br /></header>");